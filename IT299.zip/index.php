<!DOCTYPE html> 
<html>
<title>Foxy Photography - Index</title> 
<head>
</head> 
<body>
	<h1>Temporary Index to hold links for the applications before final implementation on Foxy Photography's website.</h1><br>
	
	<p>General:</p>
	<a href="http://localhost/IT299/login.php">Customer Login Screen</a><br>
	
	<p>Chat application:</p>
	<a href="http://localhost/IT299/chat/chatLogin.php">Chat Login Screen</a><br>
	<a href="http://localhost/IT299/chat/chat.php">Customer Chats Screen</a><br>
	
	<p>Shopping cart application:</p>
	<a href="http://localhost/IT299/ShoppingCart/shoppingCart.php">Shopping Cart</a><br>
	<a href="http://localhost/IT299/ShoppingCart/productList.php">List of Products</a><br>
	
	<p>Representative screens:</p>
	<a href="http://localhost/IT299/repLogin.php">Representative Login Screen</a><br>
	<a href="http://localhost/IT299/repScreen.php">Representative Status Screen</a><br>
	
</body> 
</html>