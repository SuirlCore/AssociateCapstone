<?php
$pdo = mysqli_connect("localhost", "root", "", "chats");
$pdo2 = new mysqli("localhost", "root", "", "chats");
?>